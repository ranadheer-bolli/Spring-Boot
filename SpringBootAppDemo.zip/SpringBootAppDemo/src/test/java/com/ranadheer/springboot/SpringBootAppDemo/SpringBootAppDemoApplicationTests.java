package com.ranadheer.springboot.SpringBootAppDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAppDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
