package com.ranadheer.springboot.SpringBootAppDemo.rest;

import com.ranadheer.springboot.SpringBootAppDemo.entity.Article;
import com.ranadheer.springboot.SpringBootAppDemo.entity.User;
import com.ranadheer.springboot.SpringBootAppDemo.service.ArticlesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;
import java.util.Optional;


@Controller
@RequestMapping("/articles")
public class ArticleController {

    @Autowired
    private ArticlesService articlesService;


    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable int id){
        System.out.println(id);
        articlesService.delete(id);
    }

    @GetMapping("/page")
    public String open(Model model){
        model.addAttribute("Article",new Article());
        return "new-article";
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public String addArticle(@ModelAttribute("Article") Article article) throws Exception{
        try {
            System.out.println(article);
            String name = SecurityContextHolder.getContext().getAuthentication().getName();
            Optional<User> user = articlesService.findUser(name);
            user.ifPresent(user1 -> {
                user1.add(article);
            });
            articlesService.addArticle(article);
            System.out.println(article);
            return "redirect:/";
        }
        catch (Exception e){
            System.out.println(article+"-------------------"+e);
        }
        return "redirect:/";
    }




    @GetMapping("/user")
    public String getUserArticles(Model model){
        String name = SecurityContextHolder.getContext().getAuthentication().getName();
        Optional<User> user = articlesService.findUser(name);
        user.ifPresent(user1 -> {
            model.addAttribute("userArticlesList",user1.getArticlesList());
            System.out.println(user1.getArticleList());
        });
        return "user-articles";
    }
/*
    @GetMapping("/{id}")
    public String display(@PathVariable int id,Model model){
        Article article = articlesService.get(id);
        model.addAttribute("Article",article);
        System.out.println(article);
        return "post";
    }
*/
    @PutMapping("/update")
    public Article update(@RequestBody Article article){
        System.out.println(article.getUserId());
        if(article.getUserId()==null) {
            System.out.println(article);
            articlesService.update(article);
        }
        return article;
    }


}
