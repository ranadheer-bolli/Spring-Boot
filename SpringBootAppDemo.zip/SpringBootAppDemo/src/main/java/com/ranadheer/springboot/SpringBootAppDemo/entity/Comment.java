package com.ranadheer.springboot.SpringBootAppDemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import javax.persistence.*;

@Entity
@Table(name = "comments")
public class Comment {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "comment")
    private String comment;


    @ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.REFRESH,
    CascadeType.DETACH,
    CascadeType.DETACH})
    @JoinColumn(name="article_id")
    @JsonBackReference
    private Article articleId;

    public Comment() {
    }

    public Comment(String comment) {
        this.comment = comment;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Article getArticleId() {
        return articleId;
    }

    public void setArticleId(Article articleId) {
        this.articleId = articleId;
    }
}
