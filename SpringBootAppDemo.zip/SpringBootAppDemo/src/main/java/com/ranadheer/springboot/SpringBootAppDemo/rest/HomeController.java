package com.ranadheer.springboot.SpringBootAppDemo.rest;

import com.ranadheer.springboot.SpringBootAppDemo.entity.Article;
import com.ranadheer.springboot.SpringBootAppDemo.entity.Comment;
import com.ranadheer.springboot.SpringBootAppDemo.entity.User;
import com.ranadheer.springboot.SpringBootAppDemo.service.ArticlesService;
import com.ranadheer.springboot.SpringBootAppDemo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.view.RedirectView;

import java.util.List;
import java.util.Optional;

@Controller
public class HomeController {

    @Autowired
    private ArticlesService articlesService;

    @Autowired
    private CommentService commentService;
    @GetMapping("/helloPage")
    public String hello(){
        return "hello";
    }

    @GetMapping("/")
    public String listArticles(Model theModel) {

        // get employees from db
        List<Article> articles = articlesService.get();
        System.out.println(articles);
        // add to the spring model
        theModel.addAttribute("articles", articles);

        return "articles-list";
    }


    @GetMapping("/articles/{title}")
    public String display(@PathVariable String title,Model model){
        List<Comment> comments = commentService.getComments();
        Article article = commentService.findArticle(title);
        model.addAttribute("Comment",new Comment());
        model.addAttribute("Article",article);
        model.addAttribute("comments",comments);
        System.out.println(comments);
        return "post";
    }




}
