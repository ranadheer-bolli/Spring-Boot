package com.ranadheer.springboot.SpringBootAppDemo.rest;

import com.ranadheer.springboot.SpringBootAppDemo.entity.Article;
import com.ranadheer.springboot.SpringBootAppDemo.entity.Comment;
import com.ranadheer.springboot.SpringBootAppDemo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;



@Controller
@RequestMapping("/comment")
public class CommentController {
    @Autowired
    private CommentService commentService;


    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable int id){
        System.out.println(id);
        commentService.delete(id);
    }

    @GetMapping("/page")
    public String open(Model model){
        model.addAttribute("Comment",new Comment());
        return "new-article";
    }

    @RequestMapping(value = "/add/{title}", method = RequestMethod.POST)
    public String addComment(@ModelAttribute("Comment") Comment comment,@PathVariable String title) throws Exception{
        try {
            System.out.println(comment);
          Article article = commentService.findArticle(title);
          // to add into comment list
          article.addComment(comment);
          // to save into database
          commentService.addComment(comment);
            return "redirect:/articles/"+title;
        }
        catch (Exception e){
            System.out.println(comment+"-------------------"+e);
        }
        return "redirect:/articles/";
    }

    @GetMapping("/")
    public String listComments(Model theModel) {

        // get employees from db
        List<Comment> comments= commentService.getComments();

        // add to the spring model
        theModel.addAttribute("comments", comments);

        return "articles-list";
    }



    @PutMapping("/update")
    public String update(@RequestBody Comment comment){
        if(comment.getArticleId()==null) {
           commentService.update(comment);
        }
        return "redirect:/";
    }


}
