package com.ranadheer.springboot.SpringBootAppDemo.service;

import com.ranadheer.springboot.SpringBootAppDemo.entity.Article;
import com.ranadheer.springboot.SpringBootAppDemo.entity.User;
import com.ranadheer.springboot.SpringBootAppDemo.repository.ArticleRepository;
import com.ranadheer.springboot.SpringBootAppDemo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class ArticlesServiceImpl implements ArticlesService {

    @Autowired
    private ArticleRepository articleRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public void delete(int id) {
        Article article = articleRepository.getById(id);
        articleRepository.delete(article);
        System.out.println(article);
    }

    @Override
    public Article get(int id){
       return articleRepository.findById(id).get();

    }

    @Override
    public List<Article> get() {
        return articleRepository.findAll();
    }

    @Override
    public void update(Article article) {
            articleRepository.save(article);
    }

    @Override
    @Transactional
    public void addArticle(Article article) {
           articleRepository.save(article);
    }

    @Override
    public Optional<User> findUser(String s) {
        return userRepository.findByUserName(s);
    }


}
