package com.ranadheer.springboot.SpringBootAppDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAppDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAppDemoApplication.class, args);
	}

}
