package com.ranadheer.springboot.SpringBootAppDemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "username")
    private String userName;

    @Column(name = "email")
    private String email;

    @Column(name = "phone_no")
    private String phoneNo;

    @Column(name = "password")
    private String password;

    @OneToMany(fetch = FetchType.LAZY,
            mappedBy = "userId",
            cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<Article> articleList;

    public List<Article> getArticleList() {
        return articleList;
    }

    public void setArticleList(List<Article> articleList) {
        this.articleList = articleList;
    }

    public List<Article> getArticlesList() {
        return articleList;
    }

    public void setArticlesList(List<Article> articleList) {
        this.articleList = articleList;
    }

    public User(){}
    public User(String userName,String email,String phoneNo,String password){
        this.userName=userName;
        this.password=password;
        this.phoneNo=phoneNo;
        this.email=email;
    }
    public void setId(int id){this.id=id;}
    public void setUserName(String userName){this.userName=userName;}
    public void setEmail(String email){this.email=email;}
    public void setPhoneNo(String phoneNo){this.phoneNo=phoneNo;}
    public void setPassword(String password){this.password=password;}

    public int getId(){return this.id;}
    public String getUserName(){return this.userName;}
    public String getEmail(){return this.email;}
    public String getPhoneNo(){return this.phoneNo;}
    public String getPassword(){return this.password;}


    public String toString(){
        return "Id: "+id+" Username: "+userName+" email "+email+" phone no: "+phoneNo+" password"+password;
    }

    public void add(Article article){
           if(articleList ==null){
               articleList =new ArrayList<>();
           }
           articleList.add(article);
           article.setUserId(this);
    }

}
