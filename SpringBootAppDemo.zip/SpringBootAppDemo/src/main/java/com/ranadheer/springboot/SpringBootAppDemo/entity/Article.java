package com.ranadheer.springboot.SpringBootAppDemo.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties
@Entity
@Table(name="articles")
public class Article {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "article")
    private String article;

    @Column(name = "title")
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @ManyToOne(fetch = FetchType.LAZY,cascade = {CascadeType.REFRESH,
            CascadeType.MERGE,
            CascadeType.DETACH})
    @JoinColumn(name = "user_id")
    @JsonBackReference
    private User userId;

    public List<Comment> getCommentList() {
        return commentList;
    }

    public void setCommentList(List<Comment> commentList) {
        this.commentList = commentList;
    }

    @OneToMany(mappedBy = "articleId",cascade = {CascadeType.ALL})
    @Column(name = "article")
    @JsonManagedReference
    private List<Comment> commentList;



    public Article(){}
    public Article(String article) {
        this.article = article;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getArticle() {
        return article;
    }

    public void setArticle(String article) {
        this.article = article;
    }


    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "Article{" +
                "id=" + id +
                ", article='" + article + '\'' +
                ", title='" + title + '\'' +
                ", userId=" + userId +
                '}';
    }


    public void addComment(Comment comment){
        if(commentList==null){
            commentList= new ArrayList<>();
        }
        commentList.add(comment);
        comment.setArticleId(this);
    }
}
